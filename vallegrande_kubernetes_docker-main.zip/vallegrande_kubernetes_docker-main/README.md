# 🚀 Spring Boot Kubernetes Demo

Esta es una demo sencilla para desplegar una aplicación **Spring Boot** en un clúster **Kubernetes** usando **Minikube** y **Docker**. La app muestra un saludo personalizado en una página web.

---

## 🔧 Requisitos

- 🐳 Docker instalado  
- 🏗 Minikube instalado y corriendo  
- 📦 kubectl configurado para Minikube  
- ☕ Java 17 para compilar la app  

---

## 🚀 Pasos para ejecutar el proyecto

Primero, compila la aplicación con Maven para generar el `.jar`:

```bash
./mvnw clean package
Luego, configura tu terminal para usar el Docker dentro de Minikube:


eval $(minikube docker-env)
Construye la imagen Docker con la etiqueta springboot-app:


docker build -t springboot-app .
Aplica el despliegue en Kubernetes usando tu archivo springboot-deployment.yml:


kubectl apply -f springboot-deployment.yml
Para exponer la aplicación fuera del clúster, crea un servicio de tipo LoadBalancer:


kubectl expose deployment springboot-deployment --type=LoadBalancer --port=8080
Inicia el túnel para que Minikube pueda asignar una IP externa y puedas acceder desde tu navegador:

minikube tunnel
Obtén la URL pública para acceder a la aplicación:

minikube service springboot-deployment --url
Finalmente, abre la URL mostrada en tu navegador y deberías ver el saludo personalizado 🎉

🛠 Diagnóstico y solución de problemas
Si quieres verificar que tu pod está corriendo correctamente, usa:

kubectl get pods

Si tu pod no arranca o quieres ver qué está pasando dentro, revisa los logs:
kubectl logs <nombre-del-pod>

Para listar los servicios y verificar que el LoadBalancer tenga IP asignada:
kubectl get svc

Si necesitas recrear el servicio (por ejemplo, si ya existe), elimínalo y vuelve a crear:

kubectl delete service springboot-deployment
kubectl expose deployment springboot-deployment --type=LoadBalancer --port=8080

⚠️ Notas importantes
En entornos como GitHub Codespaces la IP puede no ser localhost. Revisa la IP con el comando minikube service springboot-deployment --url.

Asegúrate que el proceso minikube tunnel esté corriendo para que el servicio LoadBalancer funcione.

El puerto asignado por Minikube puede variar, revisa siempre con kubectl get svc o con el comando del servicio.

Si minikube tunnel ya está corriendo, no inicies otro proceso, solo mantén el que ya está activo.

👤 Autor
Victor Cuaresma

✨ ¡Gracias por probar esta demo! 🚀
