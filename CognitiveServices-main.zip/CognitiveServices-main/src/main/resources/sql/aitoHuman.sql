CREATE TABLE IF NOT EXISTS aito_human
(
    id        SERIAL PRIMARY KEY NOT NULL,
    text  VARCHAR(200),
    result VARCHAR(200)
);