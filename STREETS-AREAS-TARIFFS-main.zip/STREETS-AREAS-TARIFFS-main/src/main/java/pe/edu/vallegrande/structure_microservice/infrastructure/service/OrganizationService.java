package pe.edu.vallegrande.structure_microservice.infrastructure.service;

public class OrganizationService {
}
