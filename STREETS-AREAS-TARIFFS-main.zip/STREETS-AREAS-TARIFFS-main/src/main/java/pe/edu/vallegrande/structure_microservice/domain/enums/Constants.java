package pe.edu.vallegrande.structure_microservice.domain.enums;

public enum Constants {
    ACTIVE, INACTIVE
}
