package pe.edu.vallegrande.structure_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StructureMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
